import { useEffect, useState } from "react";
import { supabase } from "@/integrations/supabase/client";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "../ui/card";
import { toast } from "sonner";
import { Badge } from "../ui/badge";
import { ScrollArea } from "../ui/scroll-area";
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from "../ui/table";
import { Button } from "../ui/button";
import { Input } from "../ui/input";
import { OrderReceipt } from "../OrderReceipt";

type OrderItem = {
  id: string;
  product_id: string;
  quantity: number;
  price: number;
};

type Order = {
  id: string;
  created_at: string;
  total_price: number;
  status: string;
  order_items?: OrderItem[];
  cancellation_reason?: string | null;
};

type UserProfile = {
  id: string;
  user_id: string;
  full_name: string;
  email: string;
  created_at: string;
  orders?: Order[];
  totalSpending?: number;
  activeOrdersCount?: number;
  cancelledOrdersCount?: number;
};

export const AdminUsers = () => {
  const [users, setUsers] = useState<UserProfile[]>([]);
  const [selectedUser, setSelectedUser] = useState<UserProfile | null>(null);
  const [loading, setLoading] = useState(true);
  const [products, setProducts] = useState<Record<string, { name: string; unit: string }>>({});
  const [expandedOrderId, setExpandedOrderId] = useState<string | null>(null);
  const [searchQuery, setSearchQuery] = useState("");
  const [showDelivered, setShowDelivered] = useState(false);
  const [showCancelled, setShowCancelled] = useState(false);

  useEffect(() => {
    fetchUsers();
  }, []);

  useEffect(() => {
    // Reset expand states when a new customer is selected
    if (selectedUser) {
      setShowDelivered(false);
      setShowCancelled(false);
      setSearchQuery("");
      setExpandedOrderId(null);
    }
  }, [selectedUser]);

  const fetchUsers = async () => {
    // First get all user IDs that have admin role
    const { data: adminRoles } = await supabase
      .from("user_roles")
      .select("user_id")
      .eq("role", "admin");

    const adminUserIds = new Set(adminRoles?.map(r => r.user_id) || []);

    const { data: profilesData, error } = await supabase
      .from("profiles")
      .select("id, user_id, full_name, email, created_at")
      .order("created_at", { ascending: false });

    if (error) {
      toast.error("Failed to load customers");
      console.error(error);
      setLoading(false);
      return;
    }

    // Filter out admin users - only show customers
    const customerProfiles = profilesData?.filter(
      profile => !adminUserIds.has(profile.user_id)
    ) || [];

    // Fetch products for order item details
    const { data: productsData } = await supabase
      .from("products")
      .select("id, name, unit");
    
    const productsMap: Record<string, { name: string; unit: string }> = {};
    productsData?.forEach((product) => {
      productsMap[product.id] = { name: product.name, unit: product.unit };
    });
    setProducts(productsMap);

    // Fetch orders with order items for each user
    const usersWithOrders = await Promise.all(
      customerProfiles.map(async (profile) => {
        const { data: ordersData } = await supabase
          .from("orders")
          .select(`
            id, 
            created_at, 
            total_price, 
            status,
            cancellation_reason,
            order_items (
              id,
              product_id,
              quantity,
              price
            )
          `)
          .eq("user_id", profile.user_id)
          .order("created_at", { ascending: false });

        const totalSpending = ordersData?.reduce(
          (sum, order) => {
            // Only count delivered orders in total spending
            if (order.status === "Delivered") {
              return sum + Number(order.total_price);
            }
            return sum;
          },
          0
        ) || 0;

        const activeOrdersCount = ordersData?.filter(
          (order) => order.status !== "Delivered" && order.status !== "Cancelled"
        ).length || 0;

        const cancelledOrdersCount = ordersData?.filter(
          (order) => order.status === "Cancelled"
        ).length || 0;

        return {
          ...profile,
          orders: ordersData || [],
          totalSpending,
          activeOrdersCount,
          cancelledOrdersCount,
        };
      })
    );

    setUsers(usersWithOrders);
    setLoading(false);
  };

  if (loading) {
    return <div className="text-center">Loading users...</div>;
  }

  const getStatusColor = (status: string) => {
    switch (status) {
      case "Pending Approval":
        return "bg-yellow-500";
      case "Approved":
        return "bg-blue-500";
      case "Processing":
        return "bg-purple-500";
      case "Shipped":
        return "bg-indigo-500";
      case "Delivered":
        return "bg-green-500";
      case "Cancelled":
        return "bg-red-500";
      default:
        return "bg-gray-500";
    }
  };

  return (
    <div className="space-y-8">
      <div>
        <h1 className="text-4xl font-bold text-gray-900">Customer Management</h1>
        <p className="text-gray-600 mt-2">Manage and view customer orders and details</p>
      </div>

      {/* Stats Cards */}
      <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
        <div className="bg-gradient-to-br from-blue-500 to-blue-600 rounded-xl shadow-lg p-6 text-white">
          <div className="flex items-center justify-between">
            <div>
              <p className="text-blue-100 text-sm font-medium">Total Customers</p>
              <p className="text-4xl font-bold mt-2">{users.length}</p>
            </div>
            <div className="text-blue-300 text-4xl">👥</div>
          </div>
        </div>
        <div className="bg-gradient-to-br from-green-500 to-green-600 rounded-xl shadow-lg p-6 text-white">
          <div className="flex items-center justify-between">
            <div>
              <p className="text-green-100 text-sm font-medium">Total Revenue</p>
              <p className="text-4xl font-bold mt-2">₹{users.reduce((sum, u) => sum + (u.totalSpending || 0), 0).toFixed(0)}</p>
            </div>
            <div className="text-green-300 text-4xl">💰</div>
          </div>
        </div>
        <div className="bg-gradient-to-br from-orange-500 to-orange-600 rounded-xl shadow-lg p-6 text-white">
          <div className="flex items-center justify-between">
            <div>
              <p className="text-orange-100 text-sm font-medium">Total Orders</p>
              <p className="text-4xl font-bold mt-2">{users.reduce((sum, u) => sum + (u.orders?.length || 0), 0)}</p>
            </div>
            <div className="text-orange-300 text-4xl">📦</div>
          </div>
        </div>
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-5 gap-6">
        {/* Customers List - Left Side */}
        <div className="lg:col-span-2">
          <div className="bg-white rounded-xl shadow-md p-6">
            <div className="mb-6">
              <h2 className="text-xl font-bold text-gray-900">All Customers</h2>
              <p className="text-gray-600 text-sm mt-1">{users.length} registered customers</p>
            </div>
            <ScrollArea className="h-[600px] pr-4">
              <div className="space-y-3">
                {users.map((user) => (
                  <div
                    key={user.id}
                    onClick={() => setSelectedUser(user)}
                    className={`p-4 rounded-lg cursor-pointer transition-all border-2 ${
                      selectedUser?.id === user.id
                        ? "border-blue-500 bg-blue-50 shadow-md"
                        : "border-gray-200 hover:border-gray-300 hover:shadow-sm bg-white"
                    }`}
                  >
                    <div className="flex items-start justify-between">
                      <div className="flex-1">
                        <div className="font-bold text-gray-900">{user.full_name}</div>
                        <div className="text-xs text-gray-600 mt-1">{user.email}</div>
                        <div className="text-xs text-gray-500 mt-1">
                          Joined: {new Date(user.created_at).toLocaleDateString()}
                        </div>
                        <div className="flex gap-2 mt-3 flex-wrap">
                          {user.activeOrdersCount! > 0 && (
                            <span className="px-2 py-1 text-xs font-medium bg-yellow-100 text-yellow-800 rounded-full">
                              {user.activeOrdersCount} Active
                            </span>
                          )}
                          {user.cancelledOrdersCount! > 0 && (
                            <span className="px-2 py-1 text-xs font-medium bg-red-100 text-red-800 rounded-full">
                              {user.cancelledOrdersCount} Cancelled
                            </span>
                          )}
                          <span className="px-2 py-1 text-xs font-medium bg-blue-100 text-blue-800 rounded-full">
                            {user.orders?.length || 0} Orders
                          </span>
                        </div>
                      </div>
                      <div className="text-right ml-2">
                        <div className="text-lg font-bold text-green-600">
                          ₹{user.totalSpending?.toFixed(2) || "0.00"}
                        </div>
                        <div className="text-xs text-gray-500">spent</div>
                      </div>
                    </div>
                  </div>
                ))}
              </div>
            </ScrollArea>
          </div>
        </div>

        {/* Customer Details - Right Side */}
        <div className="lg:col-span-3">
          {selectedUser ? (
            <div className="space-y-4">
              <div className="bg-white rounded-xl shadow-md p-6">
                <div className="flex items-center justify-between mb-6">
                  <div>
                    <h2 className="text-2xl font-bold text-gray-900">{selectedUser.full_name}'s Orders</h2>
                    <p className="text-gray-600 text-sm mt-1">
                      Total: {selectedUser.orders?.length || 0} orders • Active: {selectedUser.activeOrdersCount || 0} • 
                      Cancelled: {selectedUser.cancelledOrdersCount || 0} •
                      Total Spending: <span className="font-bold text-green-600">₹{selectedUser.totalSpending?.toFixed(2) || "0.00"}</span>
                    </p>
                  </div>
                </div>

                {/* Search Bar */}
                <div className="mb-6">
                  <Input
                    placeholder="🔍 Search by Order ID or Product name..."
                    value={searchQuery}
                    onChange={(e) => setSearchQuery(e.target.value)}
                    className="w-full rounded-lg border border-gray-300 px-4 py-2"
                  />
                </div>

                {/* Two Column Layout */}
                <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                  {/* Delivered Orders Column */}
                  <div>
                    <button
                      onClick={() => setShowDelivered(!showDelivered)}
                      className="flex items-center gap-2 font-bold mb-4 text-green-700 hover:text-green-800 cursor-pointer w-full p-3 rounded-lg hover:bg-green-50 transition-colors bg-green-50"
                    >
                      <span className="text-lg">{showDelivered ? "▼" : "▶"}</span>
                      <span className="text-lg">✓</span>
                      <span>Delivered ({selectedUser.orders?.filter(o => o.status === "Delivered").length || 0})</span>
                    </button>
                    {showDelivered && (
                      <ScrollArea className="h-[500px] pr-4">
                        <div className="space-y-3">
                          {selectedUser.orders
                            ?.filter((order) => order.status === "Delivered")
                            .filter((order) => {
                              const searchLower = searchQuery.toLowerCase();
                              const matchesOrderId = order.id.toLowerCase().includes(searchLower);
                              const matchesProduct = order.order_items?.some((item) =>
                                products[item.product_id]?.name.toLowerCase().includes(searchLower)
                              );
                              return matchesOrderId || matchesProduct;
                            })
                            .map((order) => (
                              <div key={order.id} className="border-2 border-green-200 rounded-lg overflow-hidden bg-white hover:shadow-md transition-shadow">
                                <div className="bg-gradient-to-r from-green-50 to-green-100 p-3 border-b border-green-200">
                                  <div className="flex items-center justify-between">
                                    <div>
                                      <p className="font-bold text-gray-900">
                                        Order #{order.id.slice(0, 8)}...
                                      </p>
                                      <p className="text-xs text-gray-600 mt-1">
                                        {new Date(order.created_at).toLocaleDateString()}
                                      </p>
                                    </div>
                                    <span className="px-3 py-1 bg-green-500 text-white text-xs font-bold rounded-full">
                                      Delivered
                                    </span>
                                  </div>
                                </div>
                                <div className="p-3 space-y-3">
                                  {/* Products */}
                                  <div>
                                    <p className="text-xs font-bold text-gray-700 mb-2">Products</p>
                                    <div className="space-y-2">
                                      {order.order_items?.map((item) => (
                                        <div key={item.id} className="text-xs bg-gray-50 p-2 rounded border border-gray-200">
                                          <p className="font-semibold text-gray-900">
                                            {products[item.product_id]?.name || "Unknown Product"}
                                          </p>
                                          <p className="text-gray-600 mt-1">
                                            Qty: {item.quantity} {products[item.product_id]?.unit || ""} × ₹{Number(item.price).toFixed(2)}
                                          </p>
                                        </div>
                                      ))}
                                    </div>
                                  </div>

                                  {/* Total Amount */}
                                  <div className="border-t pt-2">
                                    <p className="text-sm font-bold text-green-600">
                                      Total: ₹{Number(order.total_price).toFixed(2)}
                                    </p>
                                  </div>

                                  <Button 
                                    variant="outline"
                                    size="sm"
                                    onClick={() => setExpandedOrderId(expandedOrderId === order.id ? null : order.id)}
                                    className="w-full text-xs"
                                  >
                                    {expandedOrderId === order.id ? "Hide Receipt" : "View Receipt"}
                                  </Button>
                                  {expandedOrderId === order.id && (
                                    <div className="mt-3 pt-3 border-t">
                                      <OrderReceipt 
                                        order={order}
                                        customerName={selectedUser.full_name}
                                        customerEmail={selectedUser.email}
                                        showCustomerInfo={true}
                                      />
                                    </div>
                                  )}
                                </div>
                              </div>
                            ))}
                          {selectedUser.orders?.filter((order) => order.status === "Delivered").length === 0 && (
                            <p className="text-xs text-gray-500 text-center py-8">No delivered orders</p>
                          )}
                        </div>
                      </ScrollArea>
                    )}
                  </div>

                  {/* Cancelled Orders Column */}
                  <div>
                    <button
                      onClick={() => setShowCancelled(!showCancelled)}
                      className="flex items-center gap-2 font-bold mb-4 text-red-700 hover:text-red-800 cursor-pointer w-full p-3 rounded-lg hover:bg-red-50 transition-colors bg-red-50"
                    >
                      <span className="text-lg">{showCancelled ? "▼" : "▶"}</span>
                      <span className="text-lg">✕</span>
                      <span>Cancelled ({selectedUser.orders?.filter(o => o.status === "Cancelled").length || 0})</span>
                    </button>
                    {showCancelled && (
                      <ScrollArea className="h-[500px] pr-4">
                        <div className="space-y-3">
                          {selectedUser.orders
                            ?.filter((order) => order.status === "Cancelled")
                            .filter((order) => {
                              const searchLower = searchQuery.toLowerCase();
                              const matchesOrderId = order.id.toLowerCase().includes(searchLower);
                              const matchesProduct = order.order_items?.some((item) =>
                                products[item.product_id]?.name.toLowerCase().includes(searchLower)
                              );
                              return matchesOrderId || matchesProduct;
                            })
                            .map((order) => (
                              <div key={order.id} className="border-2 border-red-200 rounded-lg overflow-hidden bg-white hover:shadow-md transition-shadow">
                                <div className="bg-gradient-to-r from-red-50 to-red-100 p-3 border-b border-red-200">
                                  <div className="flex items-center justify-between">
                                    <div>
                                      <p className="font-bold text-gray-900">
                                        Order #{order.id.slice(0, 8)}...
                                      </p>
                                      <p className="text-xs text-gray-600 mt-1">
                                        {new Date(order.created_at).toLocaleDateString()}
                                      </p>
                                    </div>
                                    <span className="px-3 py-1 bg-red-500 text-white text-xs font-bold rounded-full">
                                      Cancelled
                                    </span>
                                  </div>
                                </div>
                                <div className="p-3 space-y-3">
                                  {/* Products */}
                                  <div>
                                    <p className="text-xs font-bold text-gray-700 mb-2">Products</p>
                                    <div className="space-y-2">
                                      {order.order_items?.map((item) => (
                                        <div key={item.id} className="text-xs bg-gray-50 p-2 rounded border border-gray-200">
                                          <p className="font-semibold text-gray-900">
                                            {products[item.product_id]?.name || "Unknown Product"}
                                          </p>
                                          <p className="text-gray-600 mt-1">
                                            Qty: {item.quantity} {products[item.product_id]?.unit || ""} × ₹{Number(item.price).toFixed(2)}
                                          </p>
                                        </div>
                                      ))}
                                    </div>
                                  </div>

                                  {/* Total Amount */}
                                  <div className="border-t pt-2">
                                    <p className="text-sm font-bold line-through text-gray-400">
                                      ₹{Number(order.total_price).toFixed(2)}
                                    </p>
                                  </div>

                                  {order.cancellation_reason && (
                                    <div className="text-xs bg-red-50 p-2 rounded border-2 border-red-200">
                                      <p className="font-bold text-red-700">Reason:</p>
                                      <p className="text-red-600 mt-1">{order.cancellation_reason}</p>
                                    </div>
                                  )}
                                </div>
                              </div>
                            ))}
                          {selectedUser.orders?.filter((order) => order.status === "Cancelled").length === 0 && (
                            <p className="text-xs text-gray-500 text-center py-8">No cancelled orders</p>
                          )}
                        </div>
                      </ScrollArea>
                    )}
                  </div>
                </div>
              </div>
            </div>
          ) : (
            <div className="bg-white rounded-xl shadow-md p-12 text-center">
              <p className="text-gray-500 text-lg">Select a customer to view their order details</p>
            </div>
          )}
        </div>
      </div>

      {users.length === 0 && (
        <div className="bg-white rounded-xl shadow-md p-12 text-center">
          <p className="text-gray-500 text-lg">No customers found</p>
        </div>
      )}
    </div>
  );
};