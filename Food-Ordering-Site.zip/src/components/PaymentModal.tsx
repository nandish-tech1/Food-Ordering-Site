import { useState } from "react";
import {
  Dialog,
  DialogContent,
  DialogHeader,
  DialogTitle,
  DialogDescription,
} from "@/components/ui/dialog";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { QrCode, CheckCircle } from "lucide-react";

interface PaymentModalProps {
  open: boolean;
  onOpenChange: (open: boolean) => void;
  totalAmount: number;
  onConfirmPayment: (utrNumber: string) => void;
  loading?: boolean;
}

export const PaymentModal = ({
  open,
  onOpenChange,
  totalAmount,
  onConfirmPayment,
  loading = false,
}: PaymentModalProps) => {
  const [utrNumber, setUtrNumber] = useState("");
  // Fixed dummy QR code image from external URL
  const qrCodeUrl = "https://api.qrserver.com/v1/create-qr-code/?size=200x200&data=upi://pay?pa=foodordering@upi&pn=FoodOrdering&am=100&tn=Food%20Order";
  const upiId = "foodordering@upi";

  const handleConfirm = () => {
    if (utrNumber.trim().length >= 6) {
      onConfirmPayment(utrNumber.trim());
    }
  };

  const isValidUtr = utrNumber.trim().length >= 6;

  return (
    <Dialog open={open} onOpenChange={onOpenChange}>
      <DialogContent className="sm:max-w-md">
        <DialogHeader>
          <DialogTitle className="flex items-center gap-2">
            <QrCode className="h-5 w-5 text-primary" />
            Complete Payment
          </DialogTitle>
          <DialogDescription>
            Scan the QR code to pay ₹{totalAmount.toFixed(2)} and enter UTR number
          </DialogDescription>
        </DialogHeader>

        <div className="space-y-6 py-4">
          {/* QR Code Section */}
          <div className="flex flex-col items-center space-y-3">
            <div className="rounded-lg border-2 border-primary/20 bg-white p-4">
              <img
                src={qrCodeUrl}
                alt="Payment QR Code"
                className="h-48 w-48 object-contain"
              />
            </div>
            <p className="text-sm text-muted-foreground text-center">
              UPI ID: {upiId}
            </p>
            <div className="rounded-md bg-primary/10 px-4 py-2">
              <p className="text-lg font-bold text-primary">₹{totalAmount.toFixed(2)}</p>
            </div>
          </div>

          {/* UTR Input Section */}
          <div className="space-y-2">
            <Label htmlFor="utr">UTR / Transaction Reference Number</Label>
            <Input
              id="utr"
              placeholder="Enter 12-digit UTR number"
              value={utrNumber}
              onChange={(e) => setUtrNumber(e.target.value)}
              className="text-center text-lg tracking-wider"
              maxLength={22}
            />
            <p className="text-xs text-muted-foreground">
              You can find UTR number in your payment app transaction details
            </p>
          </div>

          {/* Action Buttons */}
          <div className="flex gap-3">
            <Button
              variant="outline"
              onClick={() => onOpenChange(false)}
              className="flex-1"
              disabled={loading}
            >
              Cancel
            </Button>
            <Button
              onClick={handleConfirm}
              disabled={!isValidUtr || loading}
              className="flex-1"
            >
              {loading ? (
                "Processing..."
              ) : (
                <>
                  <CheckCircle className="mr-2 h-4 w-4" />
                  Confirm Payment
                </>
              )}
            </Button>
          </div>
        </div>
      </DialogContent>
    </Dialog>
  );
};
