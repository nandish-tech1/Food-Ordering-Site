import { Button } from "@/components/ui/button";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Link } from "react-router-dom";
import { useState, useEffect } from "react";
import { ArrowRight, Leaf, ShieldCheck, Truck, ShoppingCart } from "lucide-react";
import heroImage from "@/assets/hero-food.jpg";
import { Navbar } from "@/components/Navbar";
import { supabase } from "@/integrations/supabase/client";

type FoodItem = {
  id: string;
  name: string;
  price: number;
  description: string | null;
  image_url: string | null;
  unit: string;
  average_rating: number | null;
  review_count: number | null;
};

const categories = ["All"];

const Index = () => {
  const [selectedCategory, setSelectedCategory] = useState<string | null>(null);
  const [searchTerm, setSearchTerm] = useState("");
  const [foods, setFoods] = useState<FoodItem[]>([]);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    fetchFoods();
  }, []);

  const fetchFoods = async () => {
    try {
      const { data, error } = await supabase
        .from("products")
        .select("*")
        .order("name");

      if (error) {
        console.error("Error fetching foods:", error);
      } else {
        setFoods(data || []);
      }
    } catch (err) {
      console.error("Error:", err);
    } finally {
      setLoading(false);
    }
  };

  const filteredFoods = foods.filter((food) => {
    const matchesSearch = food.name.toLowerCase().includes(searchTerm.toLowerCase()) ||
      (food.description && food.description.toLowerCase().includes(searchTerm.toLowerCase()));
    return matchesSearch;
  });
  return (
    <div className="min-h-screen bg-background">
      <Navbar />
      
      {/* Hero Section */}
      <section className="relative overflow-hidden bg-gradient-to-r from-primary/90 to-accent/90">
        <div className="absolute inset-0 z-0 opacity-30"
          style={{
            backgroundImage: `url('https://images.unsplash.com/photo-1495521821757-a1efb6729352?w=1200&h=600&fit=crop')`,
            backgroundSize: 'cover',
            backgroundPosition: 'center',
          }}
        />
        
        <div className="container relative z-10 mx-auto px-4 py-32 md:py-48">
          <div className="max-w-3xl">
            <h1 className="mb-6 text-6xl font-bold leading-tight text-white md:text-7xl drop-shadow-lg">
              Order Fresh Food Online
            </h1>
            <p className="mb-8 text-xl text-white/90 drop-shadow-md">
              Discover delicious pizzas, burgers, biryanis, and refreshing juices delivered hot to your doorstep in 30-45 minutes.
            </p>
            <div className="flex flex-wrap gap-4">
              <Link to="/products">
                <Button size="lg" className="bg-white text-primary hover:bg-white/90 font-semibold shadow-lg">
                  Shop Now
                  <ArrowRight className="ml-2 h-5 w-5" />
                </Button>
              </Link>
              <Link to="/auth">
                <Button size="lg" className="bg-blue-600 hover:bg-blue-700 text-white font-semibold shadow-lg">
                  Sign Up Free
                </Button>
              </Link>
              <Link to="/admin/login">
                <Button size="lg" className="bg-amber-600 hover:bg-amber-700 text-white font-semibold shadow-lg">
                  Admin Login
                </Button>
              </Link>
            </div>
            
            {/* Quick Stats */}
            <div className="mt-12 grid grid-cols-3 gap-6 pt-8 border-t border-white/20">
              <div>
                <p className="text-3xl font-bold text-white">22+</p>
                <p className="text-sm text-white/80">Delicious Foods</p>
              </div>
              <div>
                <p className="text-3xl font-bold text-white">30 min</p>
                <p className="text-sm text-white/80">Fast Delivery</p>
              </div>
              <div>
                <p className="text-3xl font-bold text-white">100%</p>
                <p className="text-sm text-white/80">Fresh Quality</p>
              </div>
            </div>
          </div>
        </div>
      </section>

      {/* Sample Foods Section */}
      <section className="border-t py-24 bg-gradient-to-b from-primary/5 to-white">
        <div className="container mx-auto px-4">
          <div className="text-center mb-12">
            <h2 className="mb-4 text-4xl font-bold">Popular Foods</h2>
            <p className="text-lg text-muted-foreground max-w-2xl mx-auto">
              Explore our delicious selection of pizzas, burgers, biryanis, and fresh juices. All items are prepared with fresh ingredients and delivered hot to your door.
            </p>
          </div>

          {/* Products Menu Navigation */}
          <div className="mb-12 flex justify-center gap-3 flex-wrap">
            <Link to="/products">
              <Button className="gap-2 px-6 py-2 h-auto">
                <ShoppingCart className="h-4 w-4" />
                View All Products
              </Button>
            </Link>
            <Link to="/dashboard">
              <Button variant="outline" className="gap-2 px-6 py-2 h-auto">
                Dashboard
              </Button>
            </Link>
          </div>

          {/* Search Bar */}
          <div className="mb-12 max-w-2xl mx-auto">
            <div className="relative">
              <input
                type="text"
                placeholder="🔍 Search for pizzas, burgers, biryani, juices..."
                value={searchTerm}
                onChange={(e) => setSearchTerm(e.target.value)}
                className="w-full px-6 py-3 rounded-full border-2 border-primary/20 bg-white text-foreground placeholder:text-muted-foreground focus:outline-none focus:border-primary focus:ring-2 focus:ring-primary/20 shadow-md transition-all"
              />
            </div>
          </div>

          {/* Category Tabs */}
          <div className="flex justify-center gap-4 mb-12 flex-wrap">
            <Button
              variant={selectedCategory === null ? "default" : "outline"}
              onClick={() => setSelectedCategory(null)}
              className="px-6 py-2 border-2"
            >
              All Foods
            </Button>
          </div>

          {/* Foods Grid */}
          {loading ? (
            <div className="text-center py-16">
              <p className="text-lg text-muted-foreground">Loading delicious foods...</p>
            </div>
          ) : filteredFoods.length > 0 ? (
            <div className="grid gap-6 sm:grid-cols-2 lg:grid-cols-3 xl:grid-cols-4">
              {filteredFoods.map((food) => (
                <Card
                  key={food.id}
                  className="overflow-hidden hover:shadow-xl transition-all duration-300 group h-full flex flex-col border-0"
                >
                  {food.image_url && (
                    <div className="w-full h-40 overflow-hidden bg-gray-100">
                      <img
                        src={food.image_url}
                        alt={food.name}
                        className="w-full h-full object-cover group-hover:scale-110 transition-transform duration-300"
                      />
                    </div>
                  )}
                  <CardHeader className="pb-2">
                    <CardTitle className="text-lg group-hover:text-primary transition-colors line-clamp-2">
                      {food.name}
                    </CardTitle>
                    {food.average_rating !== null && food.average_rating > 0 && (
                      <div className="flex items-center gap-1 mt-1">
                        <span className="text-sm font-semibold text-yellow-500">
                          ⭐ {food.average_rating.toFixed(1)}
                        </span>
                        {food.review_count !== null && food.review_count > 0 && (
                          <span className="text-xs text-muted-foreground">
                            ({food.review_count})
                          </span>
                        )}
                      </div>
                    )}
                  </CardHeader>
                  <CardContent className="space-y-3 flex-grow pb-2">
                    {food.description && (
                      <CardDescription className="text-sm line-clamp-2">
                        {food.description}
                      </CardDescription>
                    )}
                  </CardContent>
                  <div className="px-6 pb-4 pt-2 border-t border-gray-100">
                    <div className="flex items-center justify-between gap-2">
                      <div className="flex flex-col">
                        <span className="text-2xl font-bold text-primary">
                          ₹{food.price}
                        </span>
                        <span className="text-xs text-muted-foreground">
                          per {food.unit}
                        </span>
                      </div>
                      <Link to="/products">
                        <Button size="sm" className="gap-1 bg-primary hover:bg-primary/90">
                          <ShoppingCart className="h-4 w-4" />
                          <span className="hidden sm:inline">Order</span>
                        </Button>
                      </Link>
                    </div>
                  </div>
                </Card>
              ))}
            </div>
          ) : (
            <div className="text-center py-16">
              <p className="text-lg text-muted-foreground">
                {searchTerm ? "🔍 No foods found matching your search." : "No foods available yet. Check back soon!"}
              </p>
            </div>
          )}

          <div className="text-center mt-12">
            <p className="text-muted-foreground mb-4">
              Want to see our complete menu with ratings and reviews?
            </p>
            <Link to="/products">
              <Button size="lg" className="group">
                View All Products
                <ArrowRight className="ml-2 h-5 w-5 transition-transform group-hover:translate-x-1" />
              </Button>
            </Link>
          </div>
        </div>
      </section>

      {/* Why Choose Us Section */}
      <section className="py-24 bg-gradient-to-b from-white to-primary/5">
        <div className="container mx-auto px-4">
          <div className="text-center mb-16">
            <h2 className="mb-4 text-4xl font-bold">Why Choose FoodOrdering?</h2>
            <p className="text-lg text-muted-foreground max-w-2xl mx-auto">
              We're committed to delivering the best food ordering experience with quality, speed, and reliability.
            </p>
          </div>
          
          <div className="grid gap-8 md:grid-cols-3">
            <div className="flex flex-col items-center text-center p-6 rounded-lg bg-white shadow-md hover:shadow-lg transition-shadow">
              <div className="mb-4 rounded-full bg-green-100 p-4">
                <Leaf className="h-8 w-8 text-green-600" />
              </div>
              <h3 className="mb-2 text-xl font-semibold">Fresh & Quality</h3>
              <p className="text-muted-foreground">
                All foods prepared with fresh ingredients and highest quality standards
              </p>
            </div>
            
            <div className="flex flex-col items-center text-center p-6 rounded-lg bg-white shadow-md hover:shadow-lg transition-shadow">
              <div className="mb-4 rounded-full bg-blue-100 p-4">
                <Truck className="h-8 w-8 text-blue-600" />
              </div>
              <h3 className="mb-2 text-xl font-semibold">Fast Delivery</h3>
              <p className="text-muted-foreground">
                Hot and fresh meals delivered within 30-45 minutes to your doorstep
              </p>
            </div>
            
            <div className="flex flex-col items-center text-center p-6 rounded-lg bg-white shadow-md hover:shadow-lg transition-shadow">
              <div className="mb-4 rounded-full bg-purple-100 p-4">
                <ShieldCheck className="h-8 w-8 text-purple-600" />
              </div>
              <h3 className="mb-2 text-xl font-semibold">100% Guaranteed</h3>
              <p className="text-muted-foreground">
                Satisfaction guaranteed on all orders with easy returns and refunds
              </p>
            </div>
          </div>
        </div>
      </section>
    </div>
  );
};

export default Index;