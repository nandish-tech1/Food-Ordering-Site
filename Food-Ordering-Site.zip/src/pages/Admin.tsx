import { useEffect, useState } from "react";
import { useAuth } from "@/integrations/supabase/hooks/useAuth";
import { useNavigate, useSearchParams } from "react-router-dom";
import { supabase } from "@/integrations/supabase/client";
import { Navbar } from "@/components/Navbar";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { Card, CardContent, CardHeader, CardTitle, CardDescription } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { AdminDashboard } from "@/components/admin/AdminDashboard";
import { AdminOrders } from "@/components/admin/AdminOrders";
import { AdminProducts } from "@/components/admin/AdminProducts";
import { AdminUsers } from "@/components/admin/AdminUsers";
import { AdminProfile } from "@/components/admin/AdminProfile";
import { toast } from "sonner";
import { ShoppingCart, Clock, Package, LayoutDashboard, Users, LogOut, Menu, X } from "lucide-react";

const Admin = () => {
  const { user, loading: authLoading } = useAuth();
  const navigate = useNavigate();
  const [searchParams, setSearchParams] = useSearchParams();
  const [isAdmin, setIsAdmin] = useState(false);
  const [loading, setLoading] = useState(true);
  const [sidebarOpen, setSidebarOpen] = useState(true);
  const [stats, setStats] = useState({
    totalOrders: 0,
    pendingOrders: 0,
    totalProducts: 0,
  });

  const currentTab = searchParams.get("tab") || "dashboard";

  useEffect(() => {
    if (!authLoading && !user) {
      navigate("/auth");
      return;
    }

    if (user) {
      checkAdminStatus();
    }
  }, [user, authLoading, navigate]);

  const checkAdminStatus = async () => {
    if (!user) return;

    const { data, error } = await supabase
      .from("user_roles")
      .select("role")
      .eq("user_id", user.id)
      .eq("role", "admin")
      .single();

    if (error || !data) {
      toast.error("Access denied. Admin privileges required.");
      navigate("/dashboard");
    } else {
      setIsAdmin(true);
      fetchStats();
    }
    setLoading(false);
  };

  const fetchStats = async () => {
    const { count: ordersCount } = await supabase
      .from("orders")
      .select("*", { count: "exact", head: true });

    const { count: pendingCount } = await supabase
      .from("orders")
      .select("*", { count: "exact", head: true })
      .eq("status", "Pending Approval");

    const { count: productsCount } = await supabase
      .from("products")
      .select("*", { count: "exact", head: true });

    setStats({
      totalOrders: ordersCount || 0,
      pendingOrders: pendingCount || 0,
      totalProducts: productsCount || 0,
    });
  };

  const handleTabChange = (value: string) => {
    setSearchParams({ tab: value });
  };

  const handleLogout = async () => {
    await supabase.auth.signOut();
    navigate("/");
  };

  if (authLoading || loading) {
    return (
      <div className="min-h-screen bg-gradient-to-br from-primary/5 to-accent/5">
        <Navbar />
        <div className="container mx-auto px-4 py-16">
          <div className="text-center">
            <p className="text-lg text-muted-foreground">Loading admin panel...</p>
          </div>
        </div>
      </div>
    );
  }

  if (!isAdmin) {
    return null;
  }

  const menuItems = [
    { id: "dashboard", label: "Dashboard", icon: LayoutDashboard },
    { id: "orders", label: "Orders", icon: ShoppingCart },
    { id: "products", label: "Foods", icon: Package },
    { id: "users", label: "Customers", icon: Users },
    { id: "profile", label: "Profile", icon: Users },
  ];

  return (
    <div className="min-h-screen bg-gradient-to-br from-primary/5 to-accent/5">
      <Navbar />
      
      <div className="flex">
        {/* Sidebar */}
        <div className={`${sidebarOpen ? "w-64" : "w-20"} bg-white border-r border-gray-200 transition-all duration-300 shadow-sm`}>
          <div className="flex flex-col h-[calc(100vh-80px)]">
            {/* Menu Items */}
            <nav className="flex-1 space-y-1 p-4">
              {menuItems.map((item) => {
                const Icon = item.icon;
                return (
                  <button
                    key={item.id}
                    onClick={() => handleTabChange(item.id)}
                    className={`w-full flex items-center gap-3 px-4 py-3 rounded-lg transition-all ${
                      currentTab === item.id
                        ? "bg-primary text-white"
                        : "text-gray-700 hover:bg-gray-100"
                    }`}
                  >
                    <Icon className="h-5 w-5 flex-shrink-0" />
                    {sidebarOpen && <span className="text-sm font-medium">{item.label}</span>}
                  </button>
                );
              })}
            </nav>

            {/* Logout Button */}
            <div className="border-t border-gray-200 p-4">
              <button
                onClick={handleLogout}
                className="w-full flex items-center gap-3 px-4 py-3 rounded-lg text-red-600 hover:bg-red-50 transition-all"
              >
                <LogOut className="h-5 w-5 flex-shrink-0" />
                {sidebarOpen && <span className="text-sm font-medium">Logout</span>}
              </button>
            </div>
          </div>
        </div>

        {/* Main Content */}
        <div className="flex-1">
          <div className="p-8">
            {/* Header */}
            <div className="flex justify-between items-center mb-8">
              <div>
                <h1 className="text-4xl font-bold text-gray-900">Admin Panel</h1>
                <p className="text-gray-600 mt-1">Welcome back, manage your restaurant</p>
              </div>
              <button
                onClick={() => setSidebarOpen(!sidebarOpen)}
                className="p-2 hover:bg-gray-100 rounded-lg transition-all"
              >
                {sidebarOpen ? <X className="h-6 w-6" /> : <Menu className="h-6 w-6" />}
              </button>
            </div>

            {/* Stats Cards */}
            {currentTab === "dashboard" && (
              <div className="grid grid-cols-1 md:grid-cols-3 gap-6 mb-8">
                <Card className="bg-white border-0 shadow-md hover:shadow-lg transition-shadow">
                  <CardHeader className="pb-3">
                    <CardTitle className="text-sm text-gray-600">Total Orders</CardTitle>
                  </CardHeader>
                  <CardContent>
                    <div className="flex items-end justify-between">
                      <div>
                        <p className="text-4xl font-bold text-primary">{stats.totalOrders}</p>
                      </div>
                      <ShoppingCart className="h-10 w-10 text-primary/20" />
                    </div>
                  </CardContent>
                </Card>

                <Card className="bg-white border-0 shadow-md hover:shadow-lg transition-shadow">
                  <CardHeader className="pb-3">
                    <CardTitle className="text-sm text-gray-600">Pending Orders</CardTitle>
                  </CardHeader>
                  <CardContent>
                    <div className="flex items-end justify-between">
                      <div>
                        <p className="text-4xl font-bold text-orange-600">{stats.pendingOrders}</p>
                      </div>
                      <Clock className="h-10 w-10 text-orange-600/20" />
                    </div>
                  </CardContent>
                </Card>

                <Card className="bg-white border-0 shadow-md hover:shadow-lg transition-shadow">
                  <CardHeader className="pb-3">
                    <CardTitle className="text-sm text-gray-600">Total Foods</CardTitle>
                  </CardHeader>
                  <CardContent>
                    <div className="flex items-end justify-between">
                      <div>
                        <p className="text-4xl font-bold text-green-600">{stats.totalProducts}</p>
                      </div>
                      <Package className="h-10 w-10 text-green-600/20" />
                    </div>
                  </CardContent>
                </Card>
              </div>
            )}

            {/* Content Tabs */}
            <div className="bg-white rounded-lg shadow-md p-8">
              {currentTab === "dashboard" && <AdminDashboard />}
              {currentTab === "orders" && <AdminOrders />}
              {currentTab === "products" && <AdminProducts />}
              {currentTab === "users" && <AdminUsers />}
              {currentTab === "profile" && <AdminProfile />}
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};

export default Admin;